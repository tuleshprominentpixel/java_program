create procedure all_trainee()
    language plpgsql
as
$$
begin 
	select * from trainee;
	commit;
end
$$;

alter procedure all_trainee() owner to postgres;

