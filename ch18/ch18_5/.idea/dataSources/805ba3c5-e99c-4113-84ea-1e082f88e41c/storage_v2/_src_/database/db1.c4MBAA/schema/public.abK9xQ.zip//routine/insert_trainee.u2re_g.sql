create procedure insert_trainee(IN in_name character varying, IN in_addres character varying, IN in_age integer, IN in_dob date)
    language plpgsql
as
$$
BEGIN
  INSERT INTO trainee (trainee_name, trainee_address, trainee_age,trainee_dob) 
  values (in_name,in_addres,in_age,in_dob);
  commit;
 	
  
end
$$;

alter procedure insert_trainee(varchar, varchar, integer, date) owner to postgres;

