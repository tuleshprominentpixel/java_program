create function sum_n_product(x integer, y integer, OUT sum integer, OUT prod integer) returns record
    language plpgsql
as
$$
BEGIN
    sum := x + y;
    prod := x * y;
END;
$$;

alter function sum_n_product(integer, integer, out integer, out integer) owner to postgres;

