create procedure delete_trainee(IN id integer)
    language plpgsql
as
$$
begin 
	DELETE from trainee WHERE trainee_id =id;
	commit;
end
$$;

alter procedure delete_trainee(integer) owner to postgres;

