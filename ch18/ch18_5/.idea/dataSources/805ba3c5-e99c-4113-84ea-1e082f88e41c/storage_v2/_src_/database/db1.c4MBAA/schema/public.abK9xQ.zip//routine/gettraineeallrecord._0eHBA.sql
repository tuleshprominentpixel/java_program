create function gettraineeallrecord() returns SETOF trainee
    language plpgsql
as
$$
BEGIN
    select * from trainee;
END;
$$;

alter function gettraineeallrecord() owner to postgres;

