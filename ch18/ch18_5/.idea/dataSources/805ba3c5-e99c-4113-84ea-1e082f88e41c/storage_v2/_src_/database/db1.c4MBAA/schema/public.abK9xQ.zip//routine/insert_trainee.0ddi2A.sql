create procedure insert_trainee(IN in_name character varying, IN in_addres character varying, IN in_age integer)
    language plpgsql
as
$$
BEGIN
  INSERT INTO trainee (trainee_name, trainee_address, trainee_age) 
  values (in_name,in_addres,in_age);
  commit;
 	
  
end
$$;

alter procedure insert_trainee(varchar, varchar, integer) owner to postgres;

