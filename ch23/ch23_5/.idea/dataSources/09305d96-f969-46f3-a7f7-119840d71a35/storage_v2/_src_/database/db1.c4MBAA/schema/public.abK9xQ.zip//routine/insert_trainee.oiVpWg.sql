create procedure insert_trainee(IN in_name character varying, IN in_addres character varying, IN in_dob date, IN in_join_date date, IN in_age integer, IN out_result character varying)
    language plpgsql
as
$$
BEGIN
  INSERT INTO trainee (trainee_name, trainee_address, trainee_age,trainee_dob,trainee_joining_date) 
  values (in_name,in_addres,in_age,in_dob,in_join_date);
  commit;

  
end
$$;

alter procedure insert_trainee(varchar, varchar, date, date, integer, varchar) owner to postgres;

