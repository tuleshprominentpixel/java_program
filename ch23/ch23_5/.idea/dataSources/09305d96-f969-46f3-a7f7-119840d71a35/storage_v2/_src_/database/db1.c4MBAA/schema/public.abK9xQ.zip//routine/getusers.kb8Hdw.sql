create function getusers(OUT mycurs refcursor) returns refcursor
    language plpgsql
as
$$
BEGIN       UPDATE trainee set trainee_name='Tulesh11' where trainee_id=51;select * from trainee; END;
$$;

alter function getusers(out refcursor) owner to postgres;

