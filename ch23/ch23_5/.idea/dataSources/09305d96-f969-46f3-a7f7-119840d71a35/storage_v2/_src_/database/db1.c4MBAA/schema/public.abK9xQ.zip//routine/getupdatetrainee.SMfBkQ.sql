create function getupdatetrainee(OUT mycurs refcursor) returns refcursor
    language plpgsql
as
$$
BEGIN      UPDATE trainee set trainee_name='Tulesh8' where (trainee_joining_date<= NOW() - INTERVAL '6 months' )and (trainee_joining_date> NOW() - INTERVAL '12 months');  END;
$$;

alter function getupdatetrainee(out refcursor) owner to postgres;

