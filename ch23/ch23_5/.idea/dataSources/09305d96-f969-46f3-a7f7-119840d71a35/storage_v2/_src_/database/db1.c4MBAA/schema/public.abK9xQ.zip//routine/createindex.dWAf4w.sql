create function createindex(OUT mycurs refcursor) returns refcursor
    language plpgsql
as
$$
BEGIN      create index trainee_age on trainee(trainee_age);  END;
$$;

alter function createindex(out refcursor) owner to postgres;

