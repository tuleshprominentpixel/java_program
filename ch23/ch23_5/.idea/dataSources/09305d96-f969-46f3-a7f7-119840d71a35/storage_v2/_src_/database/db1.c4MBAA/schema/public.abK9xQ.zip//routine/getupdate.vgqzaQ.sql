create function getupdate(OUT mycurs refcursor) returns refcursor
    language plpgsql
as
$$
BEGIN  OPEN mycurs FOR UPDATE trainee set trainee_name='Tulesh' where trainee_id=51;  END;
$$;

alter function getupdate(out refcursor) owner to postgres;

