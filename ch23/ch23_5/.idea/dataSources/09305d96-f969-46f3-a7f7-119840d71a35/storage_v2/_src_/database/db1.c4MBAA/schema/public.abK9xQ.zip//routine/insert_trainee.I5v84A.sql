create procedure insert_trainee(IN in_id integer, IN in_name character varying, IN in_addres character varying, IN in_dob date, IN in_join_date date, IN in_age integer, OUT out_result character varying)
    language plpgsql
as
$$
BEGIN
  INSERT INTO trainee (trainee_id, trainee_name, trainee_address, trainee_dob, trainee_joining_date,trainee_age) 
  values (in_id,in_name,in_addres,in_dob,in_join_date,in_age);
  commit;
 

  
end
$$;

alter procedure insert_trainee(integer, varchar, varchar, date, date, integer, out varchar) owner to postgres;

